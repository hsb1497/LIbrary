package com.cg.bookstore.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.exceptions.CustomerNotFoundException;
import com.cg.bookstore.services.BookStoreServices;

@Controller
public class BookStoreController
{
	@Autowired
	BookStoreServices bookStoreServices;
	
	@RequestMapping(value="/addCustomer",method=RequestMethod.POST)
	public Customer addCustomer(@ModelAttribute Customer customer){
		customer = bookStoreServices.addCustomer(customer);
		return customer;
	}
	

	@RequestMapping(value="/getCustomer",method=RequestMethod.GET)
	public Customer getCustomer(@RequestParam String email)throws CustomerNotFoundException {
		Customer customer = bookStoreServices.getCustomer(email);
		return customer;
	}
	
//	@RequestMapping("/registerUser")
//	public ModelAndView registerUser(@ModelAttribute CapBookUser user,BindingResult result)
//	{
//		if(result.hasErrors())
//			return new ModelAndView("registrationPage");
//		user = userServices.acceptUserDetails(user);
//		return new ModelAndView("loginPage","user",user);
//	}
//
//	@RequestMapping("/forgetPassword")
//	public ModelAndView forgetPassword(@RequestParam String email1,ModelMap model1) throws IncorrectUsernameException
//	{	
//		model1.put("email1", email1);
//		CapBookUser user = userServices.forgetPassword(email1);
//		return new ModelAndView("forgetPasswordSecurityQuestionPage","user",user);
//	}
//
//	@RequestMapping("/forgetPasswordSuccess")
//	public ModelAndView forgetPasswordSuccess(@SessionAttribute("email1") String email1, @RequestParam String securityAnswer) throws IncorrectUsernameException, IncorrectAnswerException
//	{	
//		boolean result = userServices.checkSecurityAnswer(email1,securityAnswer);
//		return new ModelAndView("forgetPasswordSuccessPage","email1",email1);
//	}
//
//	@RequestMapping("/changePassword")
//	public ModelAndView changePassword(@SessionAttribute("email1") String email1,@RequestParam String newPassword,@RequestParam String confirmPassword) throws IncorrectUsernameException, IncorrectAnswerException, PasswordMismatchException
//	{	
//		boolean result = userServices.changeForgettedPassword(email1,newPassword,confirmPassword);
//		return new ModelAndView("forgetPasswordSuccessPage","result",result);
//	}
//
//	
//	@RequestMapping("/loggingout")
//	public String getlogout(HttpSession session) {
//		session.invalidate();
//		return "loginPage";
//	}
}
