package com.cg.bookstore.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
    private  String name;
    @Id
    private String email;
    private String password;
    private int phoneno;
    private String address;
    private String city;
    private int zipcode;
    private String country;
    public Customer() {
        super();
    }
    public Customer(String name, String email, String password, int phoneno, String address, String city, int zipcode,
                    String country) {
        super();
        this.name = name;
        this.email = email;
        this.password = password;
        this.phoneno = phoneno;
        this.address = address;
        this.city = city;
        this.zipcode = zipcode;
        this.country = country;
    }
    
    @Override
    public String toString() {
        return "Customer [name=" + name + ", email=" + email + ", password=" + password + ", phoneno=" + phoneno
                + ", address=" + address + ", city=" + city + ", zipcode=" + zipcode + ", country=" + country + "]";
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((address == null) ? 0 : address.hashCode());
        result = prime * result + ((city == null) ? 0 : city.hashCode());
        result = prime * result + ((country == null) ? 0 : country.hashCode());
        result = prime * result + ((email == null) ? 0 : email.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((password == null) ? 0 : password.hashCode());
        result = prime * result + phoneno;
        result = prime * result + zipcode;
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Customer other = (Customer) obj;
        if (address == null) {
            if (other.address != null)
                return false;
        } else if (!address.equals(other.address))
            return false;
        if (city == null) {
            if (other.city != null)
                return false;
        } else if (!city.equals(other.city))
            return false;
        if (country == null) {
            if (other.country != null)
                return false;
        } else if (!country.equals(other.country))
            return false;
        if (email == null) {
            if (other.email != null)
                return false;
        } else if (!email.equals(other.email))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (password == null) {
            if (other.password != null)
                return false;
        } else if (!password.equals(other.password))
            return false;
        if (phoneno != other.phoneno)
            return false;
        if (zipcode != other.zipcode)
            return false;
        return true;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public int getPhoneno() {
        return phoneno;
    }
    public void setPhoneno(int phoneno) {
        this.phoneno = phoneno;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public int getZipcode() {
        return zipcode;
    }
    public void setZipcode(int zipcode) {
        this.zipcode = zipcode;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }



}