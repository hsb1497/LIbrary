package com.cg.bookstore.beans;

public class Order {
    private String name;
    private double phone;
    private String streetAddress;
    private String city;
    private int zipCode;
    private String country;
    private String shippingAddress;
    private int quantity;
    private float subtotal;
    private float total;
    private String orderStatus;
    private float paymentMethod;
    public Order() {}
    public Order(String name, double phone, String streetAddress, String city, int zipCode, String country,
                 String shippingAddress, int quantity, float subtotal, float total, String orderStatus,
                 float paymentMethod) {
        super();
        this.name = name;
        this.phone = phone;
        this.streetAddress = streetAddress;
        this.city = city;
        this.zipCode = zipCode;
        this.country = country;
        this.shippingAddress = shippingAddress;
        this.quantity = quantity;
        this.subtotal = subtotal;
        this.total = total;
        this.orderStatus = orderStatus;
        this.paymentMethod = paymentMethod;
    }
    @Override
    public String toString() {
        return "Order [name=" + name + ", phone=" + phone + ", streetAddress=" + streetAddress + ", city=" + city
                + ", zipCode=" + zipCode + ", country=" + country + ", shippingAddress=" + shippingAddress
                + ", quantity=" + quantity + ", subtotal=" + subtotal + ", total=" + total + ", orderStatus="
                + orderStatus + ", paymentMethod=" + paymentMethod + "]";
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getPhone() {
        return phone;
    }
    public void setPhone(double phone) {
        this.phone = phone;
    }
    public String getStreetAddress() {
        return streetAddress;
    }
    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public int getZipCode() {
        return zipCode;
    }
    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getShippingAddress() {
        return shippingAddress;
    }
    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public float getSubtotal() {
        return subtotal;
    }
    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }
    public float getTotal() {
        return total;
    }
    public void setTotal(float total) {
        this.total = total;
    }
    public String getOrderStatus() {
        return orderStatus;
    }
    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
    public float getPaymentMethod() {
        return paymentMethod;
    }
    public void setPaymentMethod(float paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((city == null) ? 0 : city.hashCode());
        result = prime * result + ((country == null) ? 0 : country.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((orderStatus == null) ? 0 : orderStatus.hashCode());
        result = prime * result + Float.floatToIntBits(paymentMethod);
        long temp;
        temp = Double.doubleToLongBits(phone);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + quantity;
        result = prime * result + ((shippingAddress == null) ? 0 : shippingAddress.hashCode());
        result = prime * result + ((streetAddress == null) ? 0 : streetAddress.hashCode());
        result = prime * result + Float.floatToIntBits(subtotal);
        result = prime * result + Float.floatToIntBits(total);
        result = prime * result + zipCode;
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Order other = (Order) obj;
        if (city == null) {
            if (other.city != null)
                return false;
        } else if (!city.equals(other.city))
            return false;
        if (country == null) {
            if (other.country != null)
                return false;
        } else if (!country.equals(other.country))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (orderStatus == null) {
            if (other.orderStatus != null)
                return false;
        } else if (!orderStatus.equals(other.orderStatus))
            return false;
        if (Float.floatToIntBits(paymentMethod) != Float.floatToIntBits(other.paymentMethod))
            return false;
        if (Double.doubleToLongBits(phone) != Double.doubleToLongBits(other.phone))
            return false;
        if (quantity != other.quantity)
            return false;
        if (shippingAddress == null) {
            if (other.shippingAddress != null)
                return false;
        } else if (!shippingAddress.equals(other.shippingAddress))
            return false;
        if (streetAddress == null) {
            if (other.streetAddress != null)
                return false;
        } else if (!streetAddress.equals(other.streetAddress))
            return false;
        if (Float.floatToIntBits(subtotal) != Float.floatToIntBits(other.subtotal))
            return false;
        if (Float.floatToIntBits(total) != Float.floatToIntBits(other.total))
            return false;
        if (zipCode != other.zipCode)
            return false;
        return true;
    }



}