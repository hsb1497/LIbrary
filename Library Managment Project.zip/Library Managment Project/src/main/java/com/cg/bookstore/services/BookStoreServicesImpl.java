package com.cg.bookstore.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Book;
import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.dao.BookDAO;
import com.cg.bookstore.dao.CustomerDAO;
import com.cg.bookstore.exceptions.BookNotFoundException;
import com.cg.bookstore.exceptions.CustomerNotFoundException;

@Component
public class BookStoreServicesImpl implements BookStoreServices{

	@Autowired
	CustomerDAO customerDao;
	@Autowired
	BookDAO bookDao;
	
	@Override
	public Customer addCustomer(Customer customer) {
		return customerDao.save(customer);
	}	
	@Override
	public Customer getCustomer(String email) throws CustomerNotFoundException{
		return customerDao.findById(email).orElseThrow(()->new CustomerNotFoundException("Nahi Hai Customer"));
	}
	@Override
	public void deleteCustomer(String email) {
		// TODO Auto-generated method stub
	}
	@Override
	public Customer updateCustomer(String email) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Book addBook(Book book) {
		return bookDao.save(book);
	}
	@Override
	public Book getBook(int bookId) throws BookNotFoundException {
		return bookDao.findById(bookId).orElseThrow(()->new BookNotFoundException("Book Nahi Hai"));
	}
	@Override
	public void deleteBook(int bookId) {
		// TODO Auto-generated method stub	
	}
	@Override
	public Customer updateBook(int bookId) throws BookNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
