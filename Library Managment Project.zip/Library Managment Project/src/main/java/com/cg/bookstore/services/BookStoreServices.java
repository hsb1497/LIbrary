package com.cg.bookstore.services;

import com.cg.bookstore.beans.Book;
import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.exceptions.BookNotFoundException;
import com.cg.bookstore.exceptions.CustomerNotFoundException;

public interface BookStoreServices {
	public Customer addCustomer(Customer customer);
	public Customer getCustomer(String email) throws CustomerNotFoundException;
	public void deleteCustomer(String email);
	public Customer updateCustomer(String email) throws CustomerNotFoundException;
	
	public Book addBook(Book book);
	public Book getBook(int bookId) throws BookNotFoundException; 
	public void deleteBook(int bookId);
	public Customer updateBook(int bookId) throws BookNotFoundException;
	
}
