package com.cg.bookstore.beans;
public class CustomerReview {

	private String rating;
	private String headline;
	private String comment;
	private int reviewCode;
	
	public CustomerReview() {
		super();
	}
	public CustomerReview(String rating, String headline, String comment, int reviewCode) {
		super();
		this.rating = rating;
		this.headline = headline;
		this.comment = comment;
		this.reviewCode = reviewCode;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getHeadline() {
		return headline;
	}
	public void setHeadline(String headline) {
		this.headline = headline;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getReviewCode() {
		return reviewCode;
	}
	public void setReviewCode(int reviewCode) {
		this.reviewCode = reviewCode;
	}
	
	@Override
	public String toString() {
		return "CustomerReview [rating=" + rating + ", headline=" + headline + ", comment=" + comment + ", reviewCode="
				+ reviewCode + "]";
	}
	
	
}