package com.cg.bookstore.services;

import com.cg.bookstore.beans.Customer;

public class BookStoreServicesImpl implements BookStoreServices{
    @Override
    public Customer addCustomer(Customer customer) {
        return null;
    }

    @Override
    public void deleteCustomer(String email) {

    }

    @Override
    public Customer updateCustomer(Customer customer) {
        return null;
    }
}
