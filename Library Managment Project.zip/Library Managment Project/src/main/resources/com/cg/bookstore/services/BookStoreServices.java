package com.cg.bookstore.services;

import com.cg.bookstore.beans.Customer;

public interface BookStoreServices{
    public Customer addCustomer(Customer customer);
    public void deleteCustomer(String email);
    public Customer updateCustomer(Customer customer);
}
